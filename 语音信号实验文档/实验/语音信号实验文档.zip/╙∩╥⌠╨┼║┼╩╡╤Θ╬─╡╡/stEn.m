function [En]=stEn(sp2,N,l,sampling_rate)
%sp2=x;N=winlgh;l=frmlgh;
L=length(sp2);
d=floor((L-N)/l);
sp2=sp2';
p=ones(N,1);
%�����ʱƽ������
En=zeros(1,d);
for i=1:d
En(i)=(sp2((1+(i-1)*l):(1+(i-1)*l+N-1)).^2)*p;
end
etime = length(sp2)/sampling_rate;
%figure
plot(l/sampling_rate:l/sampling_rate:l*d/sampling_rate,En);axis([0 etime min(En) max(En)]);grid;
xlabel('Time  (s)');
title('��ʱƽ������');
