function [f]=dft(x,sp);
f=fft(x);
lenth=length(f);
w=(1/lenth:1/lenth:0.5)*sp;
plot(w(2:length(w)),f(2:length(w)));
title('�ź�Ƶ��ͼ');xlabel('Hz');