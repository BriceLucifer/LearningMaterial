function [Mn]=stMn(sp2,N,l,sampling_rate)
%sp2=x;N=winlgh;l=frmlgh;
L=length(sp2);
d=floor((L-N)/l);
sp2=sp2';
p=ones(N,1);
%�����ʱƽ������
Mn=zeros(1,d);
for i=1:d
Mn(i)=abs(sp2((1+(i-1)*l):(1+(i-1)*l+N-1)))*p;
end
etime = length(sp2)/sampling_rate;
%figure
plot(l/sampling_rate:l/sampling_rate:l*d/sampling_rate,Mn);axis([0 etime min(Mn) max(Mn)]);grid;
xlabel('Time  (s)');
title('��ʱƽ������');