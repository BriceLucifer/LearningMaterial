from typing import Dict
from openai import OpenAI
import os
import base64
from mcp.server.fastmcp import FastMCP
from dotenv import load_dotenv
import logging
import cv2

# 初始化MCP服务
mcp = FastMCP("image-analyzer")
load_dotenv()

# 全局客户端初始化
client = OpenAI(
    api_key=os.getenv("DASHSCOPE_API_KEY"),
    base_url=os.getenv("DASHSCOPE_BASE_URL")
)

mcp = FastMCP("raspi-camera")

def capture_image(
    filename: str = "output.jpg",
    resolution: str = "1920x1080",
    camera_index: int = 0  # 新增摄像头设备索引参数
) -> Dict[str, str]:
    """
    跨平台USB摄像头拍照服务（OpenCV实现版）
    
    Args:
        filename: 输出文件路径（默认当前目录output.jpg）
        resolution: 分辨率格式 WidthxHeight（默认1920x1080）
        camera_index: 摄像头设备索引（默认0）
        
    Returns:
        {
            "status": "success/error",
            "path": "图片绝对路径",
            "error": "错误描述"
        }
    """
    cap = None
    try:
        # 解析分辨率
        try:
            width, height = map(int, resolution.lower().split('x'))
        except:
            raise ValueError("Invalid resolution format. Use WidthxHeight e.g. 640x480")

        # 创建目录（如果不存在）
        output_dir = os.path.dirname(filename)
        if output_dir:
            os.makedirs(output_dir, exist_ok=True)

        # 打开摄像头
        cap = cv2.VideoCapture(camera_index)
        if not cap.isOpened():
            raise RuntimeError("无法打开摄像头设备，请检查连接或设备索引")

        # 设置分辨率（实际支持的分辨率取决于摄像头驱动）
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)

        # 捕获帧
        ret, frame = cap.read()
        if not ret:
            raise RuntimeError("无法从摄像头获取画面")

        # 保存图片
        if not cv2.imwrite(filename, frame):
            raise RuntimeError("图片保存失败，请检查文件路径和权限")

        return {
            "status": "success",
            "path": os.path.abspath(filename),
            "error": ""
        }

    except Exception as e:
        logging.error(f"拍照失败: {str(e)}")
        return {
            "status": "error",
            "path": "",
            "error": f"Camera Error: {str(e)}"
        }
    finally:
        if cap is not None:
            cap.release()

async def image_describer(
    image_path: str = "output.png", # 目前是 eagle.png 后期会改成output.png
    question: str = "请详细描述这张图片的内容"
) -> Dict[str, str]:
    """
    图像内容描述工具（MCP集成版）
    
    Args:
        image_path: 图片路径/URL（默认当前目录的eagle.png）
        question: 需要解答的问题
        
    Returns:
        {
            "status": "success/error",
            "answer": "描述内容",
            "error": "错误信息（如有）"
        }
    """
    try:
        # 自动处理本地文件
        if not image_path.startswith(('http://', 'https://')):
            if not os.path.exists(image_path):
                raise FileNotFoundError(f"图片不存在: {image_path}")
                
            # 快速Base64转换
            with open(image_path, "rb") as f:
                image_data = {
                    "url": f"data:image/{image_path.split('.')[-1]};base64,{base64.b64encode(f.read()).decode()}"
                }
        else:
            image_data = {"url": image_path}

        # API请求
        resp = client.chat.completions.create(
            model="qwen-vl-max",
            messages=[{
                "role": "user",
                "content": [
                    {"type": "image_url", "image_url": image_data},
                    {"type": "text", "text": question}
                ]
            }]
        )

        return {
            "status": "success",
            "answer": resp.choices[0].message.content,
            "error": ""
        }

    except Exception as e:
        return {
            "status": "error",
            "answer": "",
            "error": str(e)
        }

@mcp.tool()
async def capture_and_analyze(
    filename: str = "output.jpg",
    resolution: str = "1920x1080",
    camera_index: int = 0,
    question: str = "请详细描述这张图片的内容,输出不要有标点符号，只要文字"
) -> Dict[str, str]:
    """
    整合式拍照分析二合一服务（MCP集成版）
    
    Args:
        filename: 输出文件路径
        resolution: 分辨率
        camera_index: 摄像头设备索引
        question: 需要解答的问题
        
    Returns:
        最终分析结果（包含可能的错误信息）
    """
    try:
        # Step 1: 拍照
        capture_res = capture_image(filename, resolution, camera_index)
        if capture_res["status"] != "success":
            return {
                "status": "error",
                "answer": "",
                "error": f"拍照失败: {capture_res['error']}"
            }

        # Step 2: 分析图片
        analyze_res = await image_describer(
            image_path=capture_res["path"],
            question=question
        )
        
        # 合并最终结果
        return {
            "status": analyze_res["status"],
            "original_path": capture_res["path"],
            "answer": analyze_res["answer"],
            "error": analyze_res.get("error", "")
        }

    except Exception as e:
        return {
            "status": "error",
            "answer": "",
            "error": f"服务链错误: {str(e)}"
        }

if __name__ == "__main__":
    mcp.run(
        transport='stdio',
    )