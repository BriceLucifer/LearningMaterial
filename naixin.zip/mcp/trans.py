"""
树莓派优化的语音识别模块
使用 Faster-Whisper 本地模型进行低延时语音识别

模型存放位置说明：
- 默认存储路径：~/.cache/huggingface/hub/
- Tiny模型：~/.cache/huggingface/hub/models--Systran--faster-whisper-tiny/
- Base模型：~/.cache/huggingface/hub/models--Systran--faster-whisper-base/
- Small模型：~/.cache/huggingface/hub/models--Systran--faster-whisper-small/

推荐配置：
- 树莓派4B：使用 tiny 模型（~39MB，延迟0.5-1s）
- 树莓派5：使用 base 模型（~74MB，延迟1-1.5s）
- 高性能需求：使用 small 模型（~244MB，延迟1.5-2s）

增强保护机制：
- 音频质量检测：过滤异常音频数据
- 重复内容过滤：避免识别结果重复
- 智能静音检测：提高语音边界检测精度
- 异常恢复机制：自动处理识别错误
"""

from faster_whisper import WhisperModel
import pyaudio
import numpy as np
import threading
import time
import queue
from typing import Generator, Optional
import gc
import os
from pathlib import Path
import hashlib
import re

# 全局控制变量
_recognition_active = True
_control_lock = threading.Lock()
_current_recognizer = None

def pause_recognition():
    """暂停语音识别"""
    global _recognition_active, _current_recognizer
    with _control_lock:
        _recognition_active = False
        if _current_recognizer:
            _current_recognizer.pause_recognition()
        print("[系统] 语音识别已暂停")

def resume_recognition():
    """恢复语音识别"""
    global _recognition_active, _current_recognizer
    with _control_lock:
        _recognition_active = True
        if _current_recognizer:
            _current_recognizer.resume_recognition()
        print("[系统] 语音识别已恢复")

class PiWhisperRecognizer:
    """
    树莓派优化的Whisper语音识别器
    
    特性：
    - 低延时设计（0.5-2秒响应）
    - 内存优化（支持树莓派有限内存）
    - 智能静音检测
    - 回声抑制机制
    - 增强的异常处理和保护机制
    """
    
    def __init__(self, model_size: str = "base"):
        """
        初始化语音识别器
        
        Args:
            model_size: 模型大小 ("tiny", "base", "small", "medium", "large")
                       推荐树莓派使用 "tiny" 或 "base"
        """
        print(f"[初始化] 正在加载 {model_size} 模型...")
        
        # 检查模型是否已下载
        self._check_model_availability(model_size)
        
        # 树莓派优化配置
        self.model = WhisperModel(
            model_size, 
            device="cpu", 
            compute_type="int8",  # 使用int8量化减少内存占用
            num_workers=1,        # 单线程避免CPU过载
            cpu_threads=2         # 限制CPU线程数
        )
        
        print(f"[初始化] {model_size} 模型加载完成")
        
        # 录音控制
        self.is_recording = False
        self.audio_queue = queue.Queue(maxsize=3)  # 限制队列大小防止内存溢出
        self.recognition_active = True
        
        # 优化的音频参数（支持更长语音识别）
        self.chunk = 1024         # 增大chunk size提升音频质量
        self.format = pyaudio.paInt16
        self.channels = 1
        self.rate = 16000
        self.record_seconds = 4.0 # 增加录音时长，支持更长句子
        self.min_audio_length = 0.3  # 最小音频长度（秒）
        
        # 优化的静音检测参数（更宽松，避免过早截断）
        self.silence_threshold = 0.005  # 降低静音阈值，更敏感检测语音
        self.silence_duration = 1.5     # 增加静音持续时间
        self.min_speech_frames = 2      # 减少最小语音帧数
        
        # 保护机制参数
        self.last_text = ""
        self.last_audio_hash = ""
        self.sentence_count = 0
        self.consecutive_errors = 0
        self.max_consecutive_errors = 3
        self.text_history = []  # 保存最近的识别历史
        self.max_history_size = 5
        
        # 异常检测参数
        self.max_repeat_chars = 10  # 最大重复字符数
        self.min_text_length = 2    # 最小文本长度
        self.max_text_length = 200  # 最大文本长度
        
        # 初始化音频设备
        try:
            self.audio = pyaudio.PyAudio()
            print("[初始化] 音频设备初始化成功")
        except Exception as e:
            print(f"[错误] 音频设备初始化失败: {e}")
            raise
        
        # 注册为全局识别器
        global _current_recognizer
        _current_recognizer = self
    
    def _check_model_availability(self, model_size: str):
        """检查模型是否已下载到本地"""
        cache_dir = Path.home() / ".cache" / "huggingface" / "hub"
        model_dir = cache_dir / f"models--Systran--faster-whisper-{model_size}"
        
        if model_dir.exists():
            print(f"[模型] {model_size} 模型已存在: {model_dir}")
        else:
            print(f"[模型] {model_size} 模型不存在，首次运行将自动下载")
            print(f"[模型] 下载位置: {model_dir}")
            
            # 显示模型大小信息
            model_sizes = {
                "tiny": "~39MB",
                "base": "~74MB", 
                "small": "~244MB",
                "medium": "~769MB",
                "large": "~1550MB"
            }
            if model_size in model_sizes:
                print(f"[模型] 预计下载大小: {model_sizes[model_size]}")
    
    def _calculate_audio_hash(self, audio_data: bytes) -> str:
        """计算音频数据的哈希值，用于检测重复音频"""
        return hashlib.md5(audio_data).hexdigest()[:16]
    
    def _is_valid_audio(self, audio_data: bytes) -> bool:
        """检查音频数据是否有效"""
        try:
            # 检查音频长度
            audio_duration = len(audio_data) / (2 * self.rate)
            if audio_duration < self.min_audio_length:
                return False
            
            # 转换为numpy数组进行分析
            audio_np = np.frombuffer(audio_data, dtype=np.int16)
            
            # 检查音频是否过于单调（可能是噪音或异常数据）
            unique_values = len(np.unique(audio_np))
            if unique_values < 10:  # 音频数据过于单调
                print("[保护] 检测到单调音频数据，跳过识别")
                return False
            
            # 检查音频幅度
            max_amplitude = np.max(np.abs(audio_np))
            if max_amplitude < 100:  # 音频信号过弱
                return False
            
            # 检查是否是重复的音频数据
            audio_hash = self._calculate_audio_hash(audio_data)
            if audio_hash == self.last_audio_hash:
                print("[保护] 检测到重复音频数据，跳过识别")
                return False
            
            self.last_audio_hash = audio_hash
            return True
            
        except Exception as e:
            print(f"[错误] 音频验证失败: {e}")
            return False
    
    def _filter_recognition_result(self, text: str) -> Optional[str]:
        """过滤和验证识别结果"""
        if not text or not text.strip():
            return None
        
        text = text.strip()
        
        # 长度检查
        if len(text) < self.min_text_length or len(text) > self.max_text_length:
            print(f"[过滤] 文本长度异常: {len(text)} 字符")
            return None
        
        # 检查重复字符
        char_counts = {}
        for char in text.replace(' ', '').replace(',', ''):
            char_counts[char] = char_counts.get(char, 0) + 1
        
        # 如果某个字符重复次数过多，可能是识别错误
        max_char_count = max(char_counts.values()) if char_counts else 0
        if max_char_count > self.max_repeat_chars:
            print(f"[过滤] 检测到重复字符过多: {text[:50]}...")
            return None
        
        # 检查是否与最近的识别结果过于相似
        for recent_text in self.text_history:
            if self._calculate_similarity(text, recent_text) > 0.8:
                print(f"[过滤] 检测到相似的重复内容")
                return None
        
        # 检查常见的误识别模式
        if self._is_common_error_pattern(text):
            print(f"[过滤] 检测到常见错误模式: {text}")
            return None
        
        # 更新历史记录
        self.text_history.append(text)
        if len(self.text_history) > self.max_history_size:
            self.text_history.pop(0)
        
        return text
    
    def _calculate_similarity(self, text1: str, text2: str) -> float:
        """计算两个文本的相似度"""
        if not text1 or not text2:
            return 0.0
        
        # 简单的字符级相似度计算
        set1 = set(text1)
        set2 = set(text2)
        intersection = len(set1.intersection(set2))
        union = len(set1.union(set2))
        
        return intersection / union if union > 0 else 0.0
    
    def _is_common_error_pattern(self, text: str) -> bool:
        """检查是否是常见的错误识别模式"""
        # 常见的错误模式
        error_patterns = [
            r'^[，。、]+$',  # 只有标点符号
            r'^[a-zA-Z]$',   # 单个英文字母
            r'^\d+$',        # 只有数字
            r'^[\s]+$',      # 只有空格
        ]
        
        for pattern in error_patterns:
            if re.match(pattern, text):
                return True
        
        return False
    
    def start_recording(self) -> Generator[str, None, None]:
        """开始录音并返回识别结果的生成器"""
        print("[录音] 开始语音识别...")
        self.is_recording = True
        self.consecutive_errors = 0
        
        # 启动录音线程
        recording_thread = threading.Thread(target=self._record_audio, daemon=True)
        recording_thread.start()
        
        # 处理音频队列并生成识别结果
        try:
            while self.is_recording:
                try:
                    if self.recognition_active:
                        # 非阻塞获取音频数据
                        audio_data = self.audio_queue.get(timeout=0.1)
                        
                        # 验证音频数据
                        if not self._is_valid_audio(audio_data):
                            continue
                        
                        text = self._transcribe_audio(audio_data)
                        
                        # 过滤识别结果
                        filtered_text = self._filter_recognition_result(text)
                        
                        if filtered_text and filtered_text != self.last_text:
                            self.sentence_count += 1
                            self.last_text = filtered_text
                            self.consecutive_errors = 0  # 重置错误计数
                            print(f"[识别] 第{self.sentence_count}句: {filtered_text}")
                            yield filtered_text
                            
                        # 强制垃圾回收释放内存（树莓派内存优化）
                        gc.collect()
                        
                except queue.Empty:
                    continue
                except Exception as e:
                    self.consecutive_errors += 1
                    print(f"[错误] 识别过程出错 ({self.consecutive_errors}/{self.max_consecutive_errors}): {e}")
                    
                    # 如果连续错误过多，暂停一段时间
                    if self.consecutive_errors >= self.max_consecutive_errors:
                        print("[保护] 连续错误过多，暂停识别5秒...")
                        time.sleep(5)
                        self.consecutive_errors = 0
                    else:
                        time.sleep(0.1)
                        
        except KeyboardInterrupt:
            print("\n[系统] 用户中断录音")
        finally:
            self.stop_recording()
    
    def _record_audio(self):
        """优化的录音线程，增加异常处理和保护机制"""
        stream = None
        retry_count = 0
        max_retries = 3
        
        while retry_count < max_retries:
            try:
                # 打开音频流
                stream = self.audio.open(
                    format=self.format,
                    channels=self.channels,
                    rate=self.rate,
                    input=True,
                    frames_per_buffer=self.chunk,
                    input_device_index=None
                )
                
                print("[录音] 录音线程启动成功")
                break
                
            except Exception as e:
                retry_count += 1
                print(f"[错误] 音频流初始化失败 (尝试 {retry_count}/{max_retries}): {e}")
                if retry_count < max_retries:
                    time.sleep(1)
                else:
                    print("[错误] 音频流初始化完全失败，退出录音")
                    return
        
        try:
            while self.is_recording:
                if not self.recognition_active:
                    time.sleep(0.1)
                    continue
                
                frames = []
                silence_frames = 0
                speech_frames = 0
                total_frames = int(self.rate / self.chunk * self.record_seconds)
                
                # 录制指定时长的音频
                for i in range(total_frames):
                    if not self.is_recording or not self.recognition_active:
                        break
                    
                    try:
                        data = stream.read(self.chunk, exception_on_overflow=False)
                        frames.append(data)
                        
                        # 安全的音量计算
                        try:
                            audio_data = np.frombuffer(data, dtype=np.int16)
                            
                            # 检查音频数据是否有效
                            if len(audio_data) == 0:
                                volume = 0.0
                            else:
                                # 使用更安全的音量计算方法
                                audio_float = audio_data.astype(np.float64)
                                mean_squared = np.mean(audio_float ** 2)
                                
                                # 确保数值有效
                                if np.isfinite(mean_squared) and mean_squared >= 0:
                                    volume = np.sqrt(mean_squared) / 32768.0
                                else:
                                    volume = 0.0
                                    
                        except (ValueError, RuntimeWarning) as e:
                            # print(f"[调试] 音量计算警告: {e}")
                            volume = 0.0
                        
                        # 静音检测
                        if volume < self.silence_threshold:
                            silence_frames += 1
                        else:
                            silence_frames = 0
                            speech_frames += 1
                            
                        # 如果连续静音时间过长，提前结束录音
                        if silence_frames > self.silence_duration * self.rate / self.chunk:
                            if speech_frames >= self.min_speech_frames:
                                break
                            
                    except Exception as e:
                        print(f"[错误] 录音数据读取失败: {e}")
                        break
                
                # 检查是否有有效音频
                if frames and self.recognition_active and speech_frames >= self.min_speech_frames:
                    audio_data = b''.join(frames)
                    
                    # 检查音频长度和质量
                    audio_duration = len(audio_data) / (2 * self.rate)
                    if audio_duration >= self.min_audio_length:
                        # 检查静音比例
                        silence_ratio = silence_frames / len(frames) if frames else 1
                        
                        if silence_ratio < 0.7:  # 降低静音比例要求
                            try:
                                # 非阻塞添加到队列
                                self.audio_queue.put_nowait(audio_data)
                            except queue.Full:
                                # 队列满时丢弃最旧的数据
                                try:
                                    self.audio_queue.get_nowait()
                                    self.audio_queue.put_nowait(audio_data)
                                except queue.Empty:
                                    pass
                
                # 短暂休息避免CPU过载
                time.sleep(0.05)
                
        except Exception as e:
            print(f"[错误] 录音线程异常: {e}")
        finally:
            if stream:
                try:
                    stream.stop_stream()
                    stream.close()
                    print("[录音] 录音流已关闭")
                except:
                    pass
    
    def _transcribe_audio(self, audio_data: bytes) -> Optional[str]:
        """使用Whisper模型转录音频，增加错误处理"""
        try:
            # 转换为numpy数组
            audio_np = np.frombuffer(audio_data, dtype=np.int16).astype(np.float32) / 32768.0
            
            # 音频预处理：降噪和标准化
            if len(audio_np) > 0:
                # 简单的音量标准化
                max_val = np.max(np.abs(audio_np))
                if max_val > 0:
                    audio_np = audio_np / max_val * 0.8
                else:
                    return None  # 无效音频
            
            # 使用Whisper转录（树莓派优化参数）
            segments, info = self.model.transcribe(
                audio_np, 
                language="zh",                    # 指定中文
                beam_size=1,                     # 减少beam size提高速度
                best_of=1,                       # 减少候选数量
                temperature=0.0,                 # 确定性输出
                compression_ratio_threshold=2.4, # 压缩比阈值
                log_prob_threshold=-1.0,         # 概率阈值
                no_speech_threshold=0.6,         # 无语音阈值
                condition_on_previous_text=False # 不依赖上下文提高速度
            )
            
            # 快速合并文本
            text_parts = []
            for segment in segments:
                if segment.text.strip():
                    text_parts.append(segment.text.strip())
            
            result = "".join(text_parts) if text_parts else None
            
            # 简单的后处理
            if result:
                result = result.strip()
                # 移除常见的识别错误
                if result in ["谢谢", "Thank you", "Bye", "再见"] and len(result) < 5:
                    return None
            
            return result
            
        except Exception as e:
            print(f"[错误] 音频转录失败: {e}")
            return None
    
    def pause_recognition(self):
        """暂停语音识别"""
        self.recognition_active = False
        # 清空队列避免处理旧音频
        while not self.audio_queue.empty():
            try:
                self.audio_queue.get_nowait()
            except queue.Empty:
                break
        print("[控制] 识别已暂停")
    
    def resume_recognition(self):
        """恢复语音识别"""
        self.recognition_active = True
        # 重置错误计数
        self.consecutive_errors = 0
        print("[控制] 识别已恢复")
    
    def stop_recording(self):
        """停止录音并清理资源"""
        print("[系统] 正在停止录音...")
        self.is_recording = False
        
        # 清理音频队列
        while not self.audio_queue.empty():
            try:
                self.audio_queue.get_nowait()
            except queue.Empty:
                break
        
        # 关闭音频设备
        if hasattr(self, 'audio'):
            try:
                self.audio.terminate()
                print("[系统] 音频设备已关闭")
            except:
                pass
        
        # 强制垃圾回收
        gc.collect()
        print("[系统] 录音已完全停止")

# 全局识别器实例
_recognizer: Optional[PiWhisperRecognizer] = None

def chatloop(model_size: str = "tiny") -> Generator[str, None, None]:
    """
    兼容原有接口的聊天循环函数
    
    Args:
        model_size: Whisper模型大小
                   - "tiny": 最快，适合树莓派3B+/4B（推荐）
                   - "base": 平衡，适合树莓派4B/5
                   - "small": 高精度，适合树莓派5或更强设备
    
    Yields:
        str: 识别到的语音文本
    """
    global _recognizer
    
    try:
        print(f"[启动] 初始化Whisper语音识别系统（模型: {model_size}）")
        _recognizer = PiWhisperRecognizer(model_size)
        
        print("[启动] 语音识别系统已就绪，请开始说话...")
        
        for text in _recognizer.start_recording():
            yield text
            
    except KeyboardInterrupt:
        print("\n[系统] 用户中断，正在清理...")
    except Exception as e:
        print(f"[错误] 语音识别系统异常: {e}")
    finally:
        if _recognizer:
            _recognizer.stop_recording()
            _recognizer = None
        print("[系统] 语音识别系统已完全关闭")

# 兼容性函数（保持与原有代码的接口一致）
def get_model_info():
    """
    获取模型信息和存储位置
    
    Returns:
        dict: 包含模型信息的字典
    """
    cache_dir = Path.home() / ".cache" / "huggingface" / "hub"
    
    models = {
        "tiny": {
            "size": "~39MB",
            "memory": "~125MB", 
            "latency": "0.5-1s",
            "path": cache_dir / "models--Systran--faster-whisper-tiny",
            "recommended_for": "树莓派3B+, 4B"
        },
        "base": {
            "size": "~74MB",
            "memory": "~210MB",
            "latency": "1-1.5s", 
            "path": cache_dir / "models--Systran--faster-whisper-base",
            "recommended_for": "树莓派4B, 5"
        },
        "small": {
            "size": "~244MB",
            "memory": "~600MB",
            "latency": "1.5-2s",
            "path": cache_dir / "models--Systran--faster-whisper-small", 
            "recommended_for": "树莓派5, 高性能设备"
        }
    }
    
    return models

if __name__ == "__main__":
    # 测试代码
    print("=== Whisper语音识别测试 ===")
    print("按 Ctrl+C 退出")
    
    try:
        for text in chatloop("tiny"):
            print(f"识别结果: {text}")
    except KeyboardInterrupt:
        print("\n测试结束")