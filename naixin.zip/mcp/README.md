# mcp_ras 使用文档（uv 版本）

## 项目简介

**mcp_ras** 是为树莓派和 macOS/Linux 设计的多功能 MCP 服务器，集成了语音识别（ASR）、语音合成（TTS）、大模型对话、工具调用等能力，适用于语音助手、智能交互等场景。

---

## 环境准备

### 1. 硬件与系统

- 推荐硬件：树莓派 4B（4G 内存及以上）或 macOS/Linux PC
- 推荐系统：Raspberry Pi OS (64位) / macOS 13+ / Ubuntu 22.04+

### 2. Python 环境

- 推荐 Python 版本：**3.12**
- 不建议使用 3.13 及以上，部分依赖不兼容

---

## 安装步骤

### 1. 安装 Python 3.12

**树莓派/Ubuntu：**
```sh
sudo apt update
sudo apt install python3.12 python3.12-venv python3.12-dev ffmpeg aplay llvm build-essential
```

### 2. 安装 uv

[uv](https://github.com/astral-sh/uv) 是一个快速的 Python 包管理工具，推荐全局安装：

```sh
pip install uv
```

### 3. 安装系统依赖

**树莓派/Ubuntu：**
```sh
sudo apt install portaudio19-dev ffmpeg libsndfile1
```

### 4. 安装 Python 依赖

项目已配置清华 PyPI 镜像，直接使用 uv 安装：

```sh
uv pip install -r requirements.txt
```
或直接用 pyproject.toml 管理：

```sh
uv sync
```

如遇 `openai-whisper` 安装问题，可手动安装：
```sh
pip install git+https://github.com/openai/whisper.git
```

---

## 启动与使用

### 1. 启动主程序


### 2. 语音交互

- 按照终端提示进行语音输入，系统会自动检测语音活动（VAD），并进行识别、对话和语音播报。
- 支持多轮对话、工具调用等功能。

---

## 主要功能说明

- **语音识别（ASR）**：支持实时语音转文本，集成 VAD（语音活动检测），只在检测到语音时进行识别。
- **语音合成（TTS）**：支持将模型回复内容通过语音播报。
- **大模型对话**：集成 OpenAI/DeepSeek 等大模型，支持多轮对话和工具调用。
- **工具调用**：支持通过自然语言调用外部工具或服务，结果自动纳入对话历史。

---

## 常见问题

- **依赖安装失败**：请确认 Python 版本为 3.12，且系统依赖已安装齐全。
- **音频相关报错**：请确认 `portaudio`、`ffmpeg`、`libsndfile` 已正确安装。
- **树莓派性能不足**：建议关闭不必要的服务，或使用更高配置的设备。

---

## 参考命令速查

```sh
# 安装依赖
uv pip install -r requirements.txt

# 或者uv sync
uv sync

# 启动服务
uv run client.py vlm.py
```

---

## 目录结构简述

- `client.py`：主客户端逻辑，负责对话、工具调用、TTS 播报等
- `trans.py`：语音识别与 VAD 相关逻辑
- `pyproject.toml`/`requirements.txt`：依赖配置
- `tts.py`: tts翻译
- `README.md`: 使用文档
- `vlm.py`: vlm模型mcp函数
---

## 联系与支持

如有问题请提交 Issue，或联系项目维护者。

---

**文档最后更新：2025-05-22**
